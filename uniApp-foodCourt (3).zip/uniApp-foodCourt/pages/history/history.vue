<template>
	<view class="content">
		
	</view>
</template>

<script setup lang="ts">
	
</script>

<style scope lang="scss">
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}
</style>
