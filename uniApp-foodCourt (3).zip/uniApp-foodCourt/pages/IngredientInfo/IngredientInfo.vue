<template>
	<div>
		配料查看
	</div>
</template>

<script setup>
</script>

<style scoped lang="scss">

</style>