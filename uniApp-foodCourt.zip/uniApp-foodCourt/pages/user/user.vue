<template>
	<view class="content">
		
	</view>
</template>

<script setup lang="ts">
import ChatPage from '@/components/hatPagec/hatPagec.vue'
</script>

<style scope lang="scss">

</style>
