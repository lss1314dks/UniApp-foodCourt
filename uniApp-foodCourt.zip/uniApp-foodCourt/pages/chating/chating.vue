<template>
	<view class="content">
		<ChatPage title="小明"  selfAvatar="/static/images/avatar.jpg" otherAvatar="/static/images/avatar.jpg"></ChatPage>
	</view>
</template>

<script setup lang="ts">
import ChatPage from '@/components/hatPagec/hatPagec.vue'
</script>

<style scope lang="scss">

</style>
