<template>
	<view class="content">
		<ChatPage title="ChatFoodCustomer"  selfAvatar="/static/images/avatar.jpg" otherAvatar="/common/images/icon2.jpg"></ChatPage>
	</view>
</template>

<script setup lang="ts">
import ChatPage from '@/components/hatPagec/hatPagec.vue'
</script>

<style scope lang="scss">

</style>
