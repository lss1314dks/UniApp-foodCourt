<template>
    <web-view :src="url"></web-view>
</template>

<script>
    export default {
        data() {
            return {
                url:''
            }
        },
        onLoad(item) {
            this.url = item.url
        }
    }
</script>

<style lang="scss">

</style>
